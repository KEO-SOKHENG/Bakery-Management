@extends('layouts.app')

@section('title', 'Staff & Accounts - Bakery Management System')

@push('styles')
    <link rel="stylesheet" href="{{ asset('css/users.css') }}?v={{ @filemtime(public_path('css/users.css')) ?: '1.0' }}">
    <link rel="stylesheet" href="{{ asset('css/orders.css') }}">
@endpush

@section('header_toolbar')
    <div class="period-pill-group">
        <a href="{{ route('admin.users.index') }}" class="period-pill active">
            <span data-lang-key="tab_staff_accounts">{{ __('messages.tab_staff_accounts') }}</span>
        </a>
        <a href="{{ route('admin.hr.attendance') }}" class="period-pill">
            <span data-lang-key="tab_attendance">{{ __('messages.tab_attendance') }}</span>
        </a>
        <a href="{{ route('admin.hr.schedules') }}" class="period-pill">
            <span data-lang-key="tab_schedules">{{ __('messages.tab_schedules') }}</span>
        </a>
        <a href="{{ route('admin.hr.salaries') }}" class="period-pill">
            <span data-lang-key="tab_salaries">{{ __('messages.tab_salaries') }}</span>
        </a>
    </div>
@endsection

@section('content')
<div class="orders-container">

    <h1 class="sr-only">User & Staff Management</h1>

<!-- Flash Notifications -->
@if(session('success'))
    <x-alert type="success" :message="session('success')" />
@endif

@if(session('error'))
    <x-alert type="danger" :message="session('error')" />
@endif

@if(session('info'))
    <x-alert type="info" :message="session('info')" />
@endif

@if($errors->any())
    <x-alert type="danger">
        <ul style="margin: 0; padding-left: 1.2rem;">
            @foreach($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </x-alert>
@endif

<!-- Summary Metric Cards (Exact Orders / Dashboard Page Style) -->
<div class="dash-stat-row">
    <div class="stat-card user-stat-card">
        <div class="stat-icon-box blue">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
        </div>
        <div class="stat-info">
            <span class="stat-label" data-lang-key="total_staff">{{ __('messages.total_staff') }}</span>
            <div class="stat-value">{{ number_format($totalUsers) }}</div>
            <span class="stat-trend up">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="18 15 12 9 6 15"/></svg>
                Team Base
            </span>
        </div>
    </div>

    <div class="stat-card user-stat-card">
        <div class="stat-icon-box green">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
        </div>
        <div class="stat-info">
            <span class="stat-label" data-lang-key="active_accounts">{{ __('messages.active_accounts') }}</span>
            <div class="stat-value">{{ number_format($activeUsers) }}</div>
            <span class="stat-trend up">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="18 15 12 9 6 15"/></svg>
                Active Staff
            </span>
        </div>
    </div>

    <div class="stat-card user-stat-card">
        <div class="stat-icon-box yellow">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>
        </div>
        <div class="stat-info">
            <span class="stat-label" data-lang-key="inactive_accounts">{{ __('messages.inactive_accounts') }}</span>
            <div class="stat-value">{{ number_format($inactiveUsers) }}</div>
            <span class="stat-trend {{ $inactiveUsers > 0 ? 'warning' : 'up' }}">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="18 15 12 9 6 15"/></svg>
                {{ $inactiveUsers > 0 ? 'Dormant' : 'All Active' }}
            </span>
        </div>
    </div>

    <div class="stat-card user-stat-card">
        <div class="stat-icon-box red">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
        </div>
        <div class="stat-info">
            <span class="stat-label" data-lang-key="suspended_accounts">{{ __('messages.suspended_accounts') }}</span>
            <div class="stat-value">{{ number_format($suspendedUsers) }}</div>
            <span class="stat-trend {{ $suspendedUsers > 0 ? 'warning' : 'up' }}">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="18 15 12 9 6 15"/></svg>
                {{ $suspendedUsers > 0 ? 'Locked' : 'Zero Issues' }}
            </span>
        </div>
    </div>
</div>

<!-- 2. Action & Filter Toolbar Row (Exact Orders & Ingredients Style) -->
<div class="ingredients-toolbar-row" id="users_toolbar" style="margin-bottom: 0.75rem; flex-shrink: 0; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.75rem;">
    <!-- Left: Filters without toolbar search input -->
    <form action="{{ route('admin.users.index') }}" method="GET" id="users_filter_form" style="display: flex; gap: 0.6rem; align-items: center; flex-wrap: wrap; margin: 0;">
        @if(request('search'))
            <input type="hidden" name="search" id="user_search_input" value="{{ request('search') }}">
        @endif

        <div class="supplier-filter-pill-card">
            <select name="role" id="user_role_select" onchange="this.form.submit()">
                <option value="" data-lang-key="all_roles">{{ __('messages.all_roles') }}</option>
                @foreach($roles as $key => $label)
                    <option value="{{ $key }}" {{ request('role') == $key ? 'selected' : '' }}>{{ $label }}</option>
                @endforeach
            </select>

            <select name="status" id="user_status_select" onchange="this.form.submit()">
                <option value="" data-lang-key="all_statuses">{{ __('messages.all_statuses') }}</option>
                @foreach($statuses as $key => $label)
                    <option value="{{ $key }}" {{ request('status') == $key ? 'selected' : '' }}>{{ $label }}</option>
                @endforeach
            </select>

            <button type="submit" class="btn" style="border-radius: 50px; padding: 0.35rem 1rem; font-weight: 700; height: 32px; display: inline-flex; align-items: center; justify-content: center; background: #ea580c; border: 1px solid #ea580c; color: #ffffff; cursor: pointer; font-size: 0.825rem;">Filter</button>

            @if(request()->hasAny(['search', 'role', 'status']) && (request('search') || request('role') || request('status')))
                <a href="{{ route('admin.users.index') }}" class="btn btn-secondary" style="border-radius: 50px; padding: 0.35rem 0.85rem; font-weight: 600; height: 32px; display: inline-flex; align-items: center; justify-content: center; font-size: 0.8rem;">Clear</a>
            @endif
        </div>
    </form>

    <!-- Right: Add Staff Button -->
    <div style="display: flex; align-items: center; gap: 0.5rem;">
        <button type="button" class="btn" id="btn_open_create_user_modal" style="border-radius: 50px; height: 36px; padding: 0 1.15rem; display: inline-flex; align-items: center; gap: 0.4rem; font-weight: 700; background: #ea580c; border: 1px solid #ea580c; color: #ffffff; cursor: pointer; font-size: 0.875rem; box-shadow: 0 2px 8px rgba(234, 88, 12, 0.25);">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            <span data-lang-key="add_staff">{{ __('messages.add_staff') }}</span>
        </button>
    </div>
</div>

<!-- 3. Users Table Card (Full Viewport Height with internal scrolling) -->
<div class="orders-card" id="users_table_card">
    <div class="orders-table-wrapper" id="users_table_wrapper">
        <table class="orders-table" id="users_table">
            <thead>
                <tr>
                    <th>Staff</th>
                    <th>Contact</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Last Active</th>
                    <th style="text-align: right;">Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($users as $user)
                    @php
                        $initials = strtoupper(substr($user->name, 0, 2));
                        $roleClass = 'role-' . strtolower($user->role);
                    @endphp
                    <tr id="user_row_{{ $user->id }}">
                        <td>
                            <div class="user-identity">
                                <div class="user-avatar">{{ $initials }}</div>
                                <div>
                                    <div class="user-name">
                                        {{ $user->name }}
                                        @if($user->id === auth()->id())
                                            <span class="user-tag-you">YOU</span>
                                        @endif
                                        @if($user->must_change_password)
                                            <span class="user-tag-temp" title="Temporary Password Pending Change">TEMP PWD</span>
                                        @endif
                                    </div>
                                    <div class="user-username">{{ '@' . $user->username }}</div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="user-email">{{ $user->email }}</div>
                            <div class="user-phone">{{ $user->phone ?? '—' }}</div>
                        </td>
                        <td>
                            <span class="role-pill {{ $roleClass }}">
                                {{ ucfirst($user->role) }}
                            </span>
                        </td>
                        <td>
                            <x-badge :variant="$user->status === 'active' ? 'success' : ($user->status === 'suspended' ? 'danger' : 'warning')">
                                {{ ucfirst($user->status) }}
                            </x-badge>
                        </td>
                        <td>
                            <div class="user-last-login">
                                {{ $user->last_login_at ? $user->last_login_at->diffForHumans() : 'Never' }}
                            </div>
                            <div class="user-joined-date">
                                Joined {{ $user->created_at ? $user->created_at->format('M d, Y') : '—' }}
                            </div>
                        </td>
                        <td>
                            <div class="user-action-group">
                                <!-- View Details & Audit Button -->
                                <button
                                    type="button"
                                    class="btn-action-btn btn-view-user"
                                    title="View Profile & Activity"
                                    data-id="{{ $user->id }}"
                                >
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                                    <span>View</span>
                                </button>

                                <!-- Edit Profile Button -->
                                <button
                                    type="button"
                                    class="btn-action-btn btn-edit-user"
                                    title="Edit Staff Member"
                                    data-id="{{ $user->id }}"
                                    data-name="{{ $user->name }}"
                                    data-username="{{ $user->username }}"
                                    data-email="{{ $user->email }}"
                                    data-phone="{{ $user->phone }}"
                                    data-role="{{ $user->role }}"
                                    data-status="{{ $user->status }}"
                                    data-mustchange="{{ $user->must_change_password ? '1' : '0' }}"
                                >
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg>
                                    <span>Edit</span>
                                </button>

                                <!-- More Actions Dropdown -->
                                <div class="user-more-wrapper">
                                    <button
                                        type="button"
                                        class="btn-action-btn btn-more-toggle"
                                        aria-haspopup="true"
                                        aria-expanded="false"
                                        title="More actions"
                                    >
                                        <span>More</span>
                                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="m6 9 6 6 6-6"/></svg>
                                    </button>

                                    <div class="user-more-menu" role="menu">
                                        <!-- Permissions -->
                                        <button
                                            type="button"
                                            class="dropdown-item btn-permissions-user"
                                            data-id="{{ $user->id }}"
                                            data-name="{{ $user->name }}"
                                            data-role="{{ $user->role }}"
                                            role="menuitem"
                                        >
                                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                                            <span>Permissions</span>
                                        </button>

                                        <!-- Change Password -->
                                        <button
                                            type="button"
                                            class="dropdown-item btn-reset-pwd-user"
                                            data-id="{{ $user->id }}"
                                            data-name="{{ $user->name }}"
                                            data-username="{{ $user->username }}"
                                            role="menuitem"
                                        >
                                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/></svg>
                                            <span>Change Password</span>
                                        </button>

                                        @if($user->id !== auth()->id())
                                            <!-- Suspend / Activate Status -->
                                            <button
                                                type="button"
                                                class="dropdown-item btn-status-user"
                                                data-id="{{ $user->id }}"
                                                data-name="{{ $user->name }}"
                                                data-status="{{ $user->status }}"
                                                role="menuitem"
                                            >
                                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="m16 12-4-4-4 4"/><path d="M12 16V8"/></svg>
                                                <span>{{ $user->status === 'active' ? 'Suspend Account' : 'Activate Account' }}</span>
                                            </button>

                                            <div class="dropdown-divider"></div>

                                            <!-- Delete Button -->
                                            <form action="{{ route('admin.users.destroy', $user->id) }}" method="POST" class="delete-user-form" onsubmit="return confirm('Are you sure you want to delete staff account \'{{ $user->username }}\'? If they have sales or order records, consider deactivating them instead.');">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="dropdown-item dropdown-item-danger delete" role="menuitem">
                                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                                                    <span>Delete Account</span>
                                                </button>
                                            </form>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 3rem; color: var(--user-muted);">
                            <div style="font-size: 2.5rem; margin-bottom: 0.5rem;">👥</div>
                            <div style="font-size: 1rem; font-weight: 700; color: var(--user-text);" data-lang-key="no_users_found">{{ __('messages.no_users_found') }}</div>
                            <p style="font-size: 0.85rem; margin-top: 0.25rem;">Try adjusting your search criteria or register a new staff account above.</p>
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
</div>

<!-- ==========================================================================
     CREATE USER MODAL
     ========================================================================== -->
<div class="user-modal-backdrop" id="create_user_modal">
    <div class="user-modal-card">
        <div class="user-modal-header">
            <h3 data-lang-key="create_user">{{ __('messages.create_user') }}</h3>
            <button type="button" class="btn-modal-close" id="btn_close_create_user">&times;</button>
        </div>
        <form action="{{ route('admin.users.store') }}" method="POST">
            @csrf
            <div class="user-modal-body">
                <div class="form-field-group">
                    <label for="create_user_name">Full Name *</label>
                    <input type="text" id="create_user_name" name="name" required placeholder="e.g. Sareth Chan">
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <div class="form-field-group">
                        <label for="create_user_username">Username *</label>
                        <input type="text" id="create_user_username" name="username" required placeholder="e.g. sareth.c">
                    </div>
                    <div class="form-field-group">
                        <label for="create_user_phone">Phone Number</label>
                        <input type="text" id="create_user_phone" name="phone" placeholder="e.g. 012 345 678">
                    </div>
                </div>

                <div class="form-field-group">
                    <label for="create_user_email">Email Address *</label>
                    <input type="email" id="create_user_email" name="email" required placeholder="e.g. staff@bakery.com">
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <div class="form-field-group">
                        <label for="create_user_role">Staff Role *</label>
                        <select id="create_user_role" name="role" required>
                            <option value="cashier" selected>Cashier</option>
                            <option value="baker">Baker</option>
                            <option value="manager">Manager</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>

                    <div class="form-field-group">
                        <label for="create_user_status">Initial Status *</label>
                        <select id="create_user_status" name="status" required>
                            <option value="active" selected>Active</option>
                            <option value="inactive">Inactive</option>
                            <option value="suspended">Suspended</option>
                        </select>
                    </div>
                </div>

                <div class="form-field-group">
                    <label for="create_user_password">Password / Temporary Password * (min 6 chars)</label>
                    <input type="password" id="create_user_password" name="password" required minlength="6" placeholder="••••••••••••">
                </div>

                <div style="margin-top: 0.5rem; background: rgba(86, 48, 32, 0.05); padding: 0.75rem; border-radius: 10px; border: 1px dashed var(--user-border);">
                    <label style="display: flex; align-items: center; gap: 0.6rem; cursor: pointer; font-size: 0.85rem; font-weight: 700; color: var(--user-text);">
                        <input type="checkbox" name="must_change_password" value="1" checked style="width: 18px; height: 18px; accent-color: #563020;">
                        <span data-lang-key="force_password_change">{{ __('messages.force_password_change') }}</span>
                    </label>
                    <div style="font-size: 0.75rem; color: var(--user-muted); margin-top: 0.25rem; margin-left: 1.8rem;">
                        If checked, the account will be forced to set a permanent password upon first login.
                    </div>
                </div>
            </div>
            <div class="user-modal-footer">
                <x-button variant="secondary" id="btn_cancel_create_user" class="btn-modal-cancel" data-lang-key="cancel">{{ __('messages.cancel') }}</x-button>
                <x-button variant="primary" type="submit" class="btn-user-primary" data-lang-key="save">{{ __('messages.save') }}</x-button>
            </div>
        </form>
    </div>
</div>

<!-- ==========================================================================
     EDIT USER MODAL
     ========================================================================== -->
<div class="user-modal-backdrop" id="edit_user_modal">
    <div class="user-modal-card">
        <div class="user-modal-header">
            <h3 data-lang-key="edit_user">{{ __('messages.edit_user') }}</h3>
            <button type="button" class="btn-modal-close" id="btn_close_edit_user">&times;</button>
        </div>
        <form id="form_edit_user" method="POST">
            @csrf
            @method('PUT')
            <div class="user-modal-body">
                <div class="form-field-group">
                    <label for="edit_user_name">Full Name *</label>
                    <input type="text" id="edit_user_name" name="name" required>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <div class="form-field-group">
                        <label for="edit_user_username">Username *</label>
                        <input type="text" id="edit_user_username" name="username" required>
                    </div>
                    <div class="form-field-group">
                        <label for="edit_user_phone">Phone Number</label>
                        <input type="text" id="edit_user_phone" name="phone">
                    </div>
                </div>

                <div class="form-field-group">
                    <label for="edit_user_email">Email Address *</label>
                    <input type="email" id="edit_user_email" name="email" required>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <div class="form-field-group">
                        <label for="edit_user_role">Staff Role *</label>
                        <select id="edit_user_role" name="role" required>
                            <option value="cashier">Cashier</option>
                            <option value="baker">Baker</option>
                            <option value="manager">Manager</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>

                    <div class="form-field-group">
                        <label for="edit_user_status">Account Status *</label>
                        <select id="edit_user_status" name="status" required>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                            <option value="suspended">Suspended</option>
                        </select>
                    </div>
                </div>

                <div class="form-field-group">
                    <label for="edit_user_password">New Password (leave empty to keep current)</label>
                    <input type="password" id="edit_user_password" name="password" minlength="6" placeholder="Optional new password">
                </div>

                <div style="margin-top: 0.5rem; background: rgba(86, 48, 32, 0.05); padding: 0.75rem; border-radius: 10px; border: 1px dashed var(--user-border);">
                    <label style="display: flex; align-items: center; gap: 0.6rem; cursor: pointer; font-size: 0.85rem; font-weight: 700; color: var(--user-text);">
                        <input type="checkbox" id="edit_must_change_password" name="must_change_password" value="1" style="width: 18px; height: 18px; accent-color: #563020;">
                        <span data-lang-key="force_password_change">{{ __('messages.force_password_change') }}</span>
                    </label>
                </div>
            </div>
            <div class="user-modal-footer">
                <x-button variant="secondary" id="btn_cancel_edit_user" class="btn-modal-cancel" data-lang-key="cancel">{{ __('messages.cancel') }}</x-button>
                <x-button variant="primary" type="submit" class="btn-user-primary" data-lang-key="save">{{ __('messages.save') }}</x-button>
            </div>
        </form>
    </div>
</div>

<!-- ==========================================================================
     RESET PASSWORD MODAL
     ========================================================================== -->
<div class="user-modal-backdrop" id="reset_password_modal">
    <div class="user-modal-card">
        <div class="user-modal-header">
            <h3 data-lang-key="reset_password">{{ __('messages.reset_password') }}</h3>
            <button type="button" class="btn-modal-close" id="btn_close_reset_pwd">&times;</button>
        </div>
        <form id="form_reset_password" method="POST">
            @csrf
            <div class="user-modal-body">
                <div style="padding: 0.75rem; background: rgba(217, 119, 6, 0.1); border: 1px solid rgba(217, 119, 6, 0.25); border-radius: 12px; font-size: 0.85rem; font-weight: 600; color: #92400e;">
                    Resetting password for: <strong id="reset_pwd_user_title">User</strong>
                </div>

                <div class="form-field-group">
                    <label for="reset_pwd_input">New Password * (min 6 characters)</label>
                    <input type="password" id="reset_pwd_input" name="password" required minlength="6" placeholder="Enter new password">
                </div>

                <div style="background: rgba(86, 48, 32, 0.05); padding: 0.75rem; border-radius: 10px; border: 1px dashed var(--user-border);">
                    <label style="display: flex; align-items: center; gap: 0.6rem; cursor: pointer; font-size: 0.85rem; font-weight: 700; color: var(--user-text);">
                        <input type="checkbox" name="must_change_password" value="1" checked style="width: 18px; height: 18px; accent-color: #563020;">
                        <span data-lang-key="force_password_change">{{ __('messages.force_password_change') }}</span>
                    </label>
                    <div style="font-size: 0.75rem; color: var(--user-muted); margin-top: 0.25rem; margin-left: 1.8rem;">
                        User will be required to change this password before accessing any bakery features upon their next login.
                    </div>
                </div>
            </div>
            <div class="user-modal-footer">
                <x-button variant="secondary" id="btn_cancel_reset_pwd" class="btn-modal-cancel" data-lang-key="cancel">{{ __('messages.cancel') }}</x-button>
                <x-button variant="warning" type="submit" class="btn-user-primary">Save New Password</x-button>
            </div>
        </form>
    </div>
</div>

<!-- ==========================================================================
     STATUS QUICK-UPDATE MODAL
     ========================================================================== -->
<div class="user-modal-backdrop" id="status_user_modal">
    <div class="user-modal-card">
        <div class="user-modal-header">
            <h3>Update Account Status</h3>
            <button type="button" class="btn-modal-close" id="btn_close_status_modal">&times;</button>
        </div>
        <form id="form_status_user" method="POST">
            @csrf
            <div class="user-modal-body">
                <div style="padding: 0.75rem; background: rgba(86, 48, 32, 0.05); border: 1px solid var(--user-border); border-radius: 12px; font-size: 0.85rem; font-weight: 600;">
                    Target User: <strong id="status_user_name"></strong>
                </div>

                <div class="form-field-group" style="margin-top: 1rem;">
                    <label for="modal_status_select">Set Account Status *</label>
                    <select id="modal_status_select" name="status" required>
                        <option value="active">Active (Full operational access)</option>
                        <option value="inactive">Inactive (Deactivated, blocked from logging in)</option>
                        <option value="suspended">Suspended (Temporarily locked due to policy)</option>
                    </select>
                </div>

                <div style="font-size: 0.8rem; color: var(--user-muted); line-height: 1.4;">
                    <strong>Historical Integrity Rule:</strong> Deactivating or suspending a staff member preserves all historical orders, sales, payments, and batch productions created by them.
                </div>
            </div>
            <div class="user-modal-footer">
                <x-button variant="secondary" id="btn_cancel_status_modal" class="btn-modal-cancel" data-lang-key="cancel">{{ __('messages.cancel') }}</x-button>
                <x-button variant="primary" type="submit" class="btn-user-primary" data-lang-key="save">{{ __('messages.save') }}</x-button>
            </div>
        </form>
    </div>
</div>

<!-- ==========================================================================
     PERMISSIONS MANAGEMENT MODAL
     ========================================================================== -->
<div class="user-modal-backdrop" id="permissions_user_modal">
    <div class="user-modal-card wide-modal">
        <div class="user-modal-header">
            <div>
                <h3 data-lang-key="manage_permissions">{{ __('messages.manage_permissions') }}</h3>
                <div style="font-size: 0.8rem; color: var(--user-muted);" id="perm_user_subtitle">
                    Configuring permissions for Staff Member
                </div>
            </div>
            <button type="button" class="btn-modal-close" id="btn_close_perm_modal">&times;</button>
        </div>
        <form id="form_update_permissions" method="POST">
            @csrf
            @method('PUT')
            <div class="user-modal-body" style="max-height: 65vh; overflow-y: auto;">
                <div id="perm_admin_notice" style="display: none; padding: 0.85rem; background: rgba(91, 33, 182, 0.1); border: 1px solid rgba(91, 33, 182, 0.3); border-radius: 12px; font-size: 0.85rem; font-weight: 700; color: #5b21b6; margin-bottom: 0.5rem;">
                    👑 <strong>Administrator Account:</strong> Admins inherently possess all module permissions unconditionally.
                </div>

                <div class="permission-modules-list" id="permission_modules_container">
                    @foreach($modules as $moduleKey => $module)
                        <div class="permission-module-card">
                            <div class="permission-module-header">
                                <div>
                                    <div class="permission-module-title">{{ $module['label'] }}</div>
                                    <div class="permission-module-desc">{{ $module['description'] }}</div>
                                </div>
                            </div>
                            <div class="permission-checkboxes-grid">
                                @foreach($module['permissions'] as $permKey => $permLabel)
                                    <label class="perm-checkbox-item">
                                        <input
                                            type="checkbox"
                                            name="permissions[{{ $permKey }}]"
                                            value="1"
                                            id="perm_check_{{ str_replace('.', '_', $permKey) }}"
                                            class="perm-checkbox"
                                            data-perm-key="{{ $permKey }}"
                                        >
                                        <div>
                                            <span>{{ $permLabel }}</span>
                                            <span class="perm-role-default-tag" id="tag_default_{{ str_replace('.', '_', $permKey) }}" style="display: none;">Default</span>
                                        </div>
                                    </label>
                                @endforeach
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
            <div class="user-modal-footer">
                <button type="button" class="btn-modal-cancel" id="btn_cancel_perm_modal" data-lang-key="cancel">{{ __('messages.cancel') }}</button>
                <button type="submit" class="btn-user-primary" id="btn_save_permissions" data-lang-key="save_permissions">{{ __('messages.save_permissions') }}</button>
            </div>
        </form>
    </div>
</div>

<!-- ==========================================================================
     USER DETAILS & AUDIT TRAIL MODAL
     ========================================================================== -->
<div class="user-modal-backdrop" id="view_user_modal">
    <div class="user-modal-card">
        <div class="user-modal-header">
            <h3 data-lang-key="user_details">{{ __('messages.user_details') }}</h3>
            <button type="button" class="btn-modal-close" id="btn_close_view_modal">&times;</button>
        </div>
        <div class="user-modal-body">
            <div style="display: flex; align-items: center; gap: 1rem; border-bottom: 1px solid var(--user-border); padding-bottom: 1rem;">
                <div class="user-avatar" id="view_user_avatar" style="width: 52px; height: 52px; font-size: 1.25rem;">SC</div>
                <div>
                    <div style="font-weight: 800; font-size: 1.15rem; color: var(--user-text);" id="view_user_name">—</div>
                    <div style="font-size: 0.825rem; color: var(--user-muted);" id="view_user_username">@username</div>
                    <div style="display: flex; gap: 0.5rem; margin-top: 0.35rem;">
                        <span class="role-pill" id="view_user_role_pill">Role</span>
                        <span class="status-badge" id="view_user_status_badge">Status</span>
                    </div>
                </div>
            </div>

            <!-- Activity / Operational Stats -->
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.75rem; text-align: center; margin: 0.5rem 0;">
                <div style="background: var(--bg-primary, #f8fafc); border: 1px solid var(--user-border); border-radius: 12px; padding: 0.65rem;">
                    <div style="font-size: 0.7rem; font-weight: 700; color: var(--user-muted);">ORDERS</div>
                    <div style="font-size: 1.2rem; font-weight: 800; color: var(--user-text);" id="view_orders_count">0</div>
                </div>
                <div style="background: var(--bg-primary, #f8fafc); border: 1px solid var(--user-border); border-radius: 12px; padding: 0.65rem;">
                    <div style="font-size: 0.7rem; font-weight: 700; color: var(--user-muted);">SALES</div>
                    <div style="font-size: 1.2rem; font-weight: 800; color: var(--user-text);" id="view_sales_count">0</div>
                </div>
                <div style="background: var(--bg-primary, #f8fafc); border: 1px solid var(--user-border); border-radius: 12px; padding: 0.65rem;">
                    <div style="font-size: 0.7rem; font-weight: 700; color: var(--user-muted);">BAKING</div>
                    <div style="font-size: 1.2rem; font-weight: 800; color: var(--user-text);" id="view_prod_count">0</div>
                </div>
            </div>

            <div>
                <h4 style="font-size: 0.85rem; font-weight: 800; text-transform: uppercase; color: var(--user-muted); margin: 0 0 0.5rem 0;" data-lang-key="audit_trail">
                    {{ __('messages.audit_trail') }}
                </h4>
                <div class="audit-timeline" id="view_user_audit_timeline">
                    <div style="font-size: 0.8rem; color: var(--user-muted); padding: 0.5rem 0;">Loading activity trail...</div>
                </div>
            </div>
        </div>
        <div class="user-modal-footer">
            <button type="button" class="btn-modal-cancel" id="btn_close_view_footer" style="width: 100%; text-align: center;">Close</button>
        </div>
    </div>
</div>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Modal Helpers
    function openModal(modal) {
        if (modal) modal.classList.add('is-active');
    }
    function closeModal(modal) {
        if (modal) modal.classList.remove('is-active');
    }

    // 0. Actions "More" Dropdown Toggle
    document.querySelectorAll('.btn-more-toggle').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            const wrapper = this.closest('.user-more-wrapper');
            const isOpen = wrapper.classList.contains('is-open');

            // Close other open dropdowns
            document.querySelectorAll('.user-more-wrapper.is-open').forEach(w => {
                if (w !== wrapper) {
                    w.classList.remove('is-open');
                    const t = w.querySelector('.btn-more-toggle');
                    if (t) t.setAttribute('aria-expanded', 'false');
                }
            });

            if (isOpen) {
                wrapper.classList.remove('is-open');
                this.setAttribute('aria-expanded', 'false');
            } else {
                wrapper.classList.add('is-open');
                this.setAttribute('aria-expanded', 'true');
            }
        });
    });

    // Close dropdown when clicking an action item
    document.querySelectorAll('.user-more-menu .dropdown-item').forEach(item => {
        item.addEventListener('click', function() {
            const wrapper = this.closest('.user-more-wrapper');
            if (wrapper) {
                wrapper.classList.remove('is-open');
                const t = wrapper.querySelector('.btn-more-toggle');
                if (t) t.setAttribute('aria-expanded', 'false');
            }
        });
    });

    // Close dropdowns on outside click
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.user-more-wrapper')) {
            document.querySelectorAll('.user-more-wrapper.is-open').forEach(w => {
                w.classList.remove('is-open');
                const t = w.querySelector('.btn-more-toggle');
                if (t) t.setAttribute('aria-expanded', 'false');
            });
        }
    });

    // Close on Escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            document.querySelectorAll('.user-more-wrapper.is-open').forEach(w => {
                w.classList.remove('is-open');
                const t = w.querySelector('.btn-more-toggle');
                if (t) t.setAttribute('aria-expanded', 'false');
            });
        }
    });

    // 1. Create User Modal
    const createModal = document.getElementById('create_user_modal');
    const btnOpenCreate = document.getElementById('btn_open_create_user_modal');
    const btnCloseCreate = document.getElementById('btn_close_create_user');
    const btnCancelCreate = document.getElementById('btn_cancel_create_user');

    if (btnOpenCreate) btnOpenCreate.addEventListener('click', () => openModal(createModal));
    if (btnCloseCreate) btnCloseCreate.addEventListener('click', () => closeModal(createModal));
    if (btnCancelCreate) btnCancelCreate.addEventListener('click', () => closeModal(createModal));

    // 2. Edit User Modal
    const editModal = document.getElementById('edit_user_modal');
    const btnCloseEdit = document.getElementById('btn_close_edit_user');
    const btnCancelEdit = document.getElementById('btn_cancel_edit_user');
    const formEdit = document.getElementById('form_edit_user');

    document.querySelectorAll('.btn-edit-user').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.dataset.id;
            formEdit.action = `/admin/users/${id}`;
            document.getElementById('edit_user_name').value = this.dataset.name || '';
            document.getElementById('edit_user_username').value = this.dataset.username || '';
            document.getElementById('edit_user_email').value = this.dataset.email || '';
            document.getElementById('edit_user_phone').value = this.dataset.phone || '';
            document.getElementById('edit_user_role').value = this.dataset.role || 'cashier';
            document.getElementById('edit_user_status').value = this.dataset.status || 'active';
            document.getElementById('edit_must_change_password').checked = (this.dataset.mustchange === '1');
            document.getElementById('edit_user_password').value = '';
            openModal(editModal);
        });
    });

    if (btnCloseEdit) btnCloseEdit.addEventListener('click', () => closeModal(editModal));
    if (btnCancelEdit) btnCancelEdit.addEventListener('click', () => closeModal(editModal));

    // 3. Reset Password Modal
    const resetModal = document.getElementById('reset_password_modal');
    const btnCloseReset = document.getElementById('btn_close_reset_pwd');
    const btnCancelReset = document.getElementById('btn_cancel_reset_pwd');
    const formReset = document.getElementById('form_reset_password');
    const resetTitle = document.getElementById('reset_pwd_user_title');

    document.querySelectorAll('.btn-reset-pwd-user').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.dataset.id;
            const name = this.dataset.name;
            const username = this.dataset.username;
            formReset.action = `/admin/users/${id}/reset-password`;
            resetTitle.textContent = `${name} (@${username})`;
            document.getElementById('reset_pwd_input').value = '';
            openModal(resetModal);
        });
    });

    if (btnCloseReset) btnCloseReset.addEventListener('click', () => closeModal(resetModal));
    if (btnCancelReset) btnCancelReset.addEventListener('click', () => closeModal(resetModal));

    // 4. Status Quick Update Modal
    const statusModal = document.getElementById('status_user_modal');
    const btnCloseStatus = document.getElementById('btn_close_status_modal');
    const btnCancelStatus = document.getElementById('btn_cancel_status_modal');
    const formStatus = document.getElementById('form_status_user');
    const statusUserName = document.getElementById('status_user_name');
    const statusSelect = document.getElementById('modal_status_select');

    document.querySelectorAll('.btn-status-user').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.dataset.id;
            const name = this.dataset.name;
            const currentStatus = this.dataset.status;
            formStatus.action = `/admin/users/${id}/status`;
            statusUserName.textContent = name;
            statusSelect.value = currentStatus;
            openModal(statusModal);
        });
    });

    if (btnCloseStatus) btnCloseStatus.addEventListener('click', () => closeModal(statusModal));
    if (btnCancelStatus) btnCancelStatus.addEventListener('click', () => closeModal(statusModal));

    // 5. Permissions Management Modal
    const permModal = document.getElementById('permissions_user_modal');
    const btnClosePerm = document.getElementById('btn_close_perm_modal');
    const btnCancelPerm = document.getElementById('btn_cancel_perm_modal');
    const formPerm = document.getElementById('form_update_permissions');
    const permSubtitle = document.getElementById('perm_user_subtitle');
    const permAdminNotice = document.getElementById('perm_admin_notice');
    const btnSavePerm = document.getElementById('btn_save_permissions');

    document.querySelectorAll('.btn-permissions-user').forEach(btn => {
        btn.addEventListener('click', async function() {
            const userId = this.dataset.id;
            const userName = this.dataset.name;
            const userRole = this.dataset.role;

            formPerm.action = `/admin/users/${userId}/permissions`;
            permSubtitle.textContent = `Configuring permissions for ${userName} (${userRole.toUpperCase()})`;

            // Fetch current permissions state
            try {
                const response = await fetch(`/admin/users/${userId}/permissions`, {
                    headers: { 'Accept': 'application/json' }
                });
                const data = await response.json();

                const isAdmin = (userRole.toLowerCase() === 'admin');
                if (isAdmin) {
                    permAdminNotice.style.display = 'block';
                    btnSavePerm.disabled = true;
                } else {
                    permAdminNotice.style.display = 'none';
                    btnSavePerm.disabled = false;
                }

                const defaults = data.role_defaults || [];
                const overrides = data.custom_overrides || {};
                const effective = data.effective_permissions || [];

                document.querySelectorAll('.perm-checkbox').forEach(cb => {
                    const key = cb.dataset.permKey;
                    const safeKey = key.replace(/\./g, '_');
                    const defaultTag = document.getElementById(`tag_default_${safeKey}`);

                    // Show or hide default badge
                    if (defaultTag) {
                        defaultTag.style.display = defaults.includes(key) ? 'inline-block' : 'none';
                    }

                    // Checked state
                    if (isAdmin) {
                        cb.checked = true;
                        cb.disabled = true;
                    } else {
                        cb.disabled = false;
                        cb.checked = effective.includes(key);
                    }
                });

                openModal(permModal);
            } catch (err) {
                console.error('Error fetching permissions:', err);
                alert('Could not load user permissions. Please try again.');
            }
        });
    });

    if (btnClosePerm) btnClosePerm.addEventListener('click', () => closeModal(permModal));
    if (btnCancelPerm) btnCancelPerm.addEventListener('click', () => closeModal(permModal));

    // 6. View User Details & Audit Trail Modal
    const viewModal = document.getElementById('view_user_modal');
    const btnCloseView = document.getElementById('btn_close_view_modal');
    const btnCloseViewFooter = document.getElementById('btn_close_view_footer');
    const viewName = document.getElementById('view_user_name');
    const viewUsername = document.getElementById('view_user_username');
    const viewAvatar = document.getElementById('view_user_avatar');
    const viewRolePill = document.getElementById('view_user_role_pill');
    const viewStatusBadge = document.getElementById('view_user_status_badge');
    const viewOrders = document.getElementById('view_orders_count');
    const viewSales = document.getElementById('view_sales_count');
    const viewProd = document.getElementById('view_prod_count');
    const viewTimeline = document.getElementById('view_user_audit_timeline');

    document.querySelectorAll('.btn-view-user').forEach(btn => {
        btn.addEventListener('click', async function() {
            const userId = this.dataset.id;
            viewTimeline.innerHTML = '<div style="font-size: 0.8rem; color: var(--user-muted); padding: 0.5rem 0;">Loading activity history...</div>';
            openModal(viewModal);

            try {
                const response = await fetch(`/admin/users/${userId}`, {
                    headers: { 'Accept': 'application/json' }
                });
                const data = await response.json();
                const u = data.user;

                viewName.textContent = u.name;
                viewUsername.textContent = `@${u.username}`;
                viewAvatar.textContent = (u.name || '').substring(0, 2).toUpperCase();

                viewRolePill.className = `role-pill role-${u.role}`;
                viewRolePill.textContent = u.role.toUpperCase();

                viewStatusBadge.className = `status-badge status-${u.status}`;
                viewStatusBadge.innerHTML = `<span class="status-dot"></span> ${u.status.toUpperCase()}`;

                viewOrders.textContent = u.orders_count || 0;
                viewSales.textContent = u.sales_count || 0;
                viewProd.textContent = u.productions_count || 0;

                const audits = data.recent_audits || [];
                if (audits.length === 0) {
                    viewTimeline.innerHTML = '<div style="font-size: 0.8rem; color: var(--user-muted); padding: 0.5rem 0;">No recorded audit events yet.</div>';
                } else {
                    viewTimeline.innerHTML = audits.map(a => {
                        const dateStr = new Date(a.created_at).toLocaleString();
                        return `
                            <div class="audit-timeline-item">
                                <div>
                                    <div class="audit-action-title">${escapeHtml(a.description || a.action)}</div>
                                    <div class="audit-meta-time">${dateStr} • IP: ${a.ip_address || '—'}</div>
                                </div>
                            </div>
                        `;
                    }).join('');
                }
            } catch (err) {
                console.error('Error fetching user details:', err);
                viewTimeline.innerHTML = '<div style="font-size: 0.8rem; color: #ef4444; padding: 0.5rem 0;">Failed to load user details.</div>';
            }
        });
    });

    if (btnCloseView) btnCloseView.addEventListener('click', () => closeModal(viewModal));
    if (btnCloseViewFooter) btnCloseViewFooter.addEventListener('click', () => closeModal(viewModal));

    // Close on backdrop click
    document.querySelectorAll('.user-modal-backdrop').forEach(backdrop => {
        backdrop.addEventListener('click', function(e) {
            if (e.target === this) closeModal(this);
        });
    });

    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
});
</script>
@endpush
@endsection
